module.exports = {
  apps: [{
    name: 'wsbot',
    script: 'src/index.js',
    cwd: __dirname,
    instances: 1,                 // WAJIB 1: username bot_admin tidak boleh login ganda
    exec_mode: 'fork',
    autorestart: true,
    min_uptime: '30s',
    max_restarts: 10,
    exponential_backoff_restart_delay: 15000,
    max_memory_restart: '350M',
    kill_timeout: 8000,
    time: true,                   // timestamp di log
    env: { NODE_ENV: 'production' }
  }]
}
