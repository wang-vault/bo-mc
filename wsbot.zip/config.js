'use strict'
// Semua pengaturan bot ada di sini. Bisa dioverride lewat env var (MC_HOST, MC_PORT, MC_VERSION, MC_USERNAME).
module.exports = {
  server: {
    host: process.env.MC_HOST || 'node2.wangstore.web.id',
    port: parseInt(process.env.MC_PORT || '25571', 10),
    username: process.env.MC_USERNAME || 'bot_admin',
    version: process.env.MC_VERSION || '26.3',
    auth: 'offline'
  },

  reconnect: {
    baseMs: 15000,            // jeda awal
    maxMs: 600000,            // batas maksimum 10 menit
    throttleMinMs: 90000,     // minimal jeda kalau kena "Connection throttled"
    duplicateMinMs: 120000,   // minimal jeda kalau kena duplicate_login
    invalidMoveMinMs: 45000,  // minimal jeda kalau kena invalid_player_movement
    stableAfterMs: 60000      // koneksi dianggap stabil setelah ini, baru counter backoff di-reset
  },

  respawn: {
    waitBeforeManualMs: 6000, // tunggu auto-respawn mineflayer dulu
    retryEveryMs: 15000,
    maxRetries: 3,
    settleMs: 3000            // jeda setelah spawn sebelum lanjut berpikir
  },

  survival: {
    retreatHealth: 8,         // <= ini: mundur
    resumeHealth: 16,         // istirahat sampai health >= ini
    fightMinHealth: 14,       // minimal health untuk mulai bertarung
    eatBelowFood: 14,         // makan kalau food <= ini
    hungryFood: 8,            // sangat lapar -> prioritas cari makan
    minFoodItems: 3           // kalau stok makanan < ini, berburu hewan saat ada kesempatan
  },

  durability: {
    replaceBelowFraction: 0.15, // ganti/craft alat baru saat sisa durability < 15%
    minUsableFraction: 0.03     // di bawah ini alat tidak dipakai lagi
  },

  combat: {
    seekRadius: 20,
    maxGroup: 3,              // lebih dari ini = kelompok berbahaya, mundur
    attackCooldownMs: 650,
    fightMaxMs: 20000,
    reach: 3.2
  },

  gather: {
    searchRadius: 48,
    logsWanted: 12,
    cobbleWanted: 24
  },

  timeouts: {                 // batas waktu per task (ms)
    GATHER_RESOURCES: 90000,
    CRAFT_EQUIPMENT: 40000,
    REPAIR_OR_REPLACE: 40000,
    FIND_FOOD: 70000,
    EXPLORE: 45000,
    FIGHT: 30000,
    RETREAT: 20000,
    RECOVER: 70000,
    EAT: 8000,
    REST: 6000
  },

  blacklistTtlMs: 600000,     // posisi/entity yang gagal dihindari selama ini
  tickMs: 1000,               // interval loop keputusan (task berjalan = tick dilewati)
  statusEveryMs: 5000,
  statusFile: require('path').join(__dirname, 'status.json'),
  lockFile: require('path').join(__dirname, 'bot.pid')
}
