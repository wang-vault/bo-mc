# WangStore Survival AI (bot_admin)

Bot survival Mineflayer berbasis aturan (state machine), tanpa LLM. Satu proses, satu bot, ringan untuk VPS 1 GB / 2 vCPU.

## Struktur

```
config.js                 semua pengaturan (host, port, threshold, cooldown, timeout)
ecosystem.config.js       konfigurasi PM2 (instances: 1)
src/index.js              koneksi, single-instance lock, reconnect exponential backoff
src/brain.js              state machine, respawn, status, deteksi proteksi/XP
src/skills/survival.js    makan, berburu, retreat, rest, recover item kematian
src/skills/gather.js      kayu, batu, coal, explore (dengan blacklist area/blok)
src/skills/craft.js       crafting table, planks, stick, tool
src/skills/combat.js      penilaian ancaman, target aman, attack loop
src/skills/equipment.js   armor, monitoring durability, ganti alat
src/skills/progression.js urutan tujuan berdasarkan isi inventory
src/status.js             `npm run status`
```

## Instalasi di /root/mc-bot

```bash
# 1. hentikan bot lama dan BACKUP dulu
pm2 stop all
cp -r /root/mc-bot /root/mc-bot-backup-$(date +%Y%m%d-%H%M)

# 2. salin file baru (jangan hapus node_modules lama kalau mau cepat)
#    unzip wsbot.zip lalu salin isinya ke /root/mc-bot
cd /root/mc-bot
npm install

# 3. jalankan
pm2 start ecosystem.config.js
pm2 save
```

PENTING: jangan mengubah `package.json` agar menambahkan `minecraft-data` sendiri. Fork `@wp2508/mineflayer`
meng-alias `minecraft-data` ke `@wp2508/minecraft-data` (yang mengenal 26.3). Versi upstream TIDAK mengenal 26.3.
Kode ini memakai `bot.registry` supaya selalu konsisten dengan library.

## PM2

```bash
pm2 start ecosystem.config.js     # start
pm2 stop wsbot                    # stop
pm2 restart wsbot                 # restart
pm2 status                        # status
pm2 logs wsbot --lines 100        # logs
npm run status                    # status bot (state, health, posisi, kills, deaths, dst.)
```

Pastikan hanya satu proses: `pm2 status` harus menampilkan satu `wsbot`, dan bot lama (nama lain) harus sudah di-stop/delete
(`pm2 delete <nama-lama>`). Selain itu bot punya lock file `bot.pid` yang menolak start kalau instance lain masih hidup.

## Cara kerja singkat

- Tiap 1 detik `decide()` memilih state dari kondisi nyata: ancaman, health, food, target, durability, tujuan progres.
- Prioritas: `RETREAT/REST` > `EAT` > `FIGHT` > `RECOVER` > `FIND_FOOD` > `REPAIR_OR_REPLACE` > `EXPLORE` > `GATHER/CRAFT`.
- Setiap task punya timeout dan token pembatalan; saat mati/disconnect/low health pathfinding dihentikan.
- Task yang gagal 3x dijeda 2 menit supaya tidak berputar tanpa hasil.
- Progres: kayu -> crafting table -> wooden pickaxe -> cobblestone -> stone pickaxe/sword/axe -> stok kayu/cobble -> coal.
- Dig yang ditolak server atau pesan "claim/permission" setelah menggali -> area di-blacklist 30 menit.
- Mob aman dilawan (zombie, husk, drowned, zombie_villager, spider, slime, skeleton bila health >= 16).
  Creeper dan mob berbahaya lain = mundur. Pemain TIDAK pernah ditarget.
- Respawn: tunggu auto-respawn Mineflayer 6 detik, baru fallback manual maksimal 3x (jeda 15 detik).
  Setelah spawn, bot cek ulang kondisi dan mencoba mengambil item di titik kematian (jika < 200 blok & aman).
- AuraSkills: bot TIDAK mengklaim XP naik. Ia hanya mencatat jika ada pesan XP yang benar-benar terlihat di chat/actionbar.
  Bila tidak ada, log menulis `[SKILL] AuraSkills XP status unverified`.

## Keterbatasan (jujur)

1. **Belum diuji di server**. Yang sudah dicek: sintaks, load modul, kompatibilitas data 26.3 dan recipe (lihat checklist). Perilaku in-game belum.
2. Belum ada smelting / furnace, jadi tidak ada iron tools, armor besi, atau makanan matang. Armor hanya dipakai kalau didapat dari loot.
3. Repair via anvil / Mending belum diimplementasi. "Ganti" = craft alat kayu/batu baru. Item ber-Mending diperbaiki pasif oleh XP orb bila dipakai/dipegang.
4. Pertahanan creeper hanya lari; bot bisa tetap terkena ledakan.
5. Tidak ada tidur/bed, tidak ada base, tidak ada chest storage, tidak ada farming.
6. Deteksi proteksi GriefPrevention bersifat heuristik (blok dikembalikan server / pesan chat tertentu).
7. `invalid_player_movement` berasal dari anti-cheat/plugin; bot hanya memakai gerak pathfinder normal, tapi tidak ada jaminan bebas kick. Kalau berulang, cek log Paper/AdvancedEnchantments.
8. Pesan XP AuraSkills tergantung konfigurasi server (actionbar bisa dimatikan). Kalau tidak terlihat, cek di game: `/skills`.
9. Versi 26.3 baru: kalau protokol berubah, bisa muncul error packet dari library, bukan dari logika bot.

## Checklist pengujian

Status "SELESAI" = sudah dijalankan; "BELUM" = perlu diuji di server dengan bot hidup.

| # | Tes | Status |
|---|-----|--------|
| 1 | `node --check` semua file | SELESAI (lolos) |
| 2 | `npm install` bersih, lockfile dibuat | SELESAI (lolos) |
| 3 | `minecraft-data` untuk 26.3 tersedia lewat fork (1286 blok, 1010 recipe) | SELESAI (lolos) |
| 4 | Modul `brain` dapat di-load | SELESAI (lolos) |
| 5 | Login + spawn + log `[LOGIN]` | BELUM |
| 6 | Single-instance lock menolak start kedua | BELUM |
| 7 | Reconnect backoff setelah kick/throttle | BELUM |
| 8 | Kumpul kayu, craft table + wooden pickaxe | BELUM |
| 9 | Kumpul cobblestone, craft tool batu | BELUM |
| 10 | Makan otomatis, berburu hewan | BELUM |
| 11 | Combat zombie + retreat saat health rendah | BELUM |
| 12 | Mati -> auto-respawn -> lanjut (cek `[DEATH]`/`[RESPAWN]`) | BELUM |
| 13 | Blacklist area proteksi | BELUM |
| 14 | Pesan XP AuraSkills terdeteksi | BELUM |
| 15 | PM2 start/restart/logs, penggunaan RAM < 300 MB | BELUM |

Urutan uji yang disarankan: jalankan `node src/index.js` langsung (bukan PM2) 5-10 menit untuk melihat log, baru pakai PM2.

## Tuning cepat

Semua di `config.js`: `survival.retreatHealth`, `survival.fightMinHealth`, `durability.replaceBelowFraction`,
`combat.maxGroup`, `reconnect.*`, `timeouts.*`. Override koneksi lewat env: `MC_HOST`, `MC_PORT`, `MC_VERSION`, `MC_USERNAME`.
