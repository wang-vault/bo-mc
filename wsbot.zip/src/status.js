'use strict'
// Pakai: npm run status
const fs = require('fs')
const cfg = require('../config')
try {
  const s = JSON.parse(fs.readFileSync(cfg.statusFile, 'utf8'))
  const age = Math.round((Date.now() - s.updatedAt) / 1000)
  console.log(age > 30 ? `!! Status stale (${age}s). Bot mungkin mati/tidak berjalan.\n` : '')
  const m = (n) => Math.floor(n / 60) + 'm ' + (n % 60) + 's'
  console.log(`Connection : ${s.connection}`)
  console.log(`State      : ${s.state}   Goal: ${s.goal ? s.goal.type + ' ' + s.goal.what : '-'}`)
  console.log(`Health/Food: ${s.health}/20  ${s.food}/20`)
  console.log(`Position   : ${s.position}`)
  console.log(`Target     : ${s.target || '-'}`)
  console.log(`Held       : ${s.held || '-'}   Armor: ${s.armor.map((a) => a || '-').join(' | ')}`)
  console.log(`Durability : ${JSON.stringify(s.durability)}`)
  console.log(`Kills/Death: ${s.kills}/${s.deaths}`)
  console.log(`Uptime     : ${m(s.uptimeSec)}  (pid ${s.pid})`)
  console.log(`AuraSkills : ${s.auraSkills}`)
  console.log(`Inventory  : ${s.inventory || '(empty)'}`)
} catch (e) {
  console.log('Belum ada status (bot belum jalan?):', e.message)
}
