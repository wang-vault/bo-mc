'use strict'
const { goals } = require('mineflayer-pathfinder')

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

function withTimeout(promise, ms, onTimeout) {
  let t
  const timeout = new Promise((_, rej) => {
    t = setTimeout(() => {
      if (onTimeout) onTimeout()
      rej(new Error('timeout'))
    }, ms)
  })
  return Promise.race([promise, timeout]).finally(() => clearTimeout(t))
}

const countItem = (bot, name) =>
  bot.inventory.items().filter((i) => i.name === name).reduce((a, i) => a + i.count, 0)

const countSuffix = (bot, suffix) =>
  bot.inventory.items().filter((i) => i.name.endsWith(suffix)).reduce((a, i) => a + i.count, 0)

// Prioritas material (copper ada di versi baru, aman kalau tidak ada)
const TIERS = { netherite: 6, diamond: 5, iron: 4, copper: 3.2, stone: 3, golden: 2, wooden: 1 }
const tierOf = (name) => TIERS[name.split('_')[0]] || 0

function durabilityFraction(item, mcData) {
  const max = mcData.items[item.type] && mcData.items[item.type].maxDurability
  if (!max) return null
  const used = item.durabilityUsed != null ? item.durabilityUsed
    : (item.nbt && item.nbt.value && item.nbt.value.Damage ? item.nbt.value.Damage.value : 0)
  return (max - used) / max
}

// Item tool terbaik dengan durability masih layak. Prefer yang di atas threshold ganti.
function bestItem(ctx, suffix) {
  const { bot, mcData, cfg } = ctx
  const cands = bot.inventory.items().filter((i) => i.name.endsWith(suffix))
  let good = null
  let worn = null
  for (const it of cands) {
    const f = durabilityFraction(it, mcData)
    const frac = f == null ? 1 : f
    if (frac < cfg.durability.minUsableFraction) continue
    if (frac >= cfg.durability.replaceBelowFraction) {
      if (!good || tierOf(it.name) > tierOf(good.name)) good = it
    } else if (!worn || tierOf(it.name) > tierOf(worn.name)) worn = it
  }
  return good || worn
}

// Jalan ke goal dengan batas waktu + bisa dibatalkan lewat token
async function goto(ctx, goal, timeoutMs) {
  const { bot, token } = ctx
  if (token.cancelled) return false
  const poll = setInterval(() => { if (token.cancelled) bot.pathfinder.stop() }, 200)
  try {
    await withTimeout(bot.pathfinder.goto(goal), timeoutMs, () => bot.pathfinder.stop())
    return true
  } catch (e) {
    bot.pathfinder.stop()
    return false
  } finally {
    clearInterval(poll)
  }
}

const gotoNear = (ctx, pos, range, ms) =>
  goto(ctx, new goals.GoalNear(pos.x, pos.y, pos.z, range), ms)

const isDrop = (e) => e && (e.name === 'item' || e.displayName === 'Item')

async function collectDrops(ctx, radius = 8) {
  const { bot, token } = ctx
  const drops = Object.values(bot.entities)
    .filter((e) => isDrop(e) && e.position.distanceTo(bot.entity.position) <= radius)
    .sort((a, b) => a.position.distanceTo(bot.entity.position) - b.position.distanceTo(bot.entity.position))
    .slice(0, 6)
  for (const d of drops) {
    if (token.cancelled) return
    await gotoNear(ctx, d.position, 1, 6000)
  }
}

// Blacklist (posisi blok / entity) dengan kedaluwarsa
function blacklist(mem, key, ttl) { mem.blacklist.set(key, Date.now() + ttl) }
function isBlacklisted(mem, key) {
  const exp = mem.blacklist.get(key)
  if (!exp) return false
  if (Date.now() > exp) { mem.blacklist.delete(key); return false }
  return true
}
const posKey = (p) => `b:${p.x},${p.y},${p.z}`
// Blacklist area (radius) di sekitar posisi, dipakai untuk claim/proteksi
function blacklistArea(mem, pos, radius, ttl) {
  mem.areas.push({ x: pos.x, y: pos.y, z: pos.z, r: radius, exp: Date.now() + ttl })
  mem.areas = mem.areas.filter((a) => a.exp > Date.now()).slice(-30)
}
function inBlockedArea(mem, pos) {
  const now = Date.now()
  return mem.areas.some((a) => a.exp > now && Math.abs(a.x - pos.x) <= a.r && Math.abs(a.z - pos.z) <= a.r)
}

module.exports = {
  sleep, withTimeout, countItem, countSuffix, tierOf, durabilityFraction, bestItem,
  goto, gotoNear, collectDrops, isDrop, blacklist, isBlacklisted, posKey, blacklistArea, inBlockedArea
}
