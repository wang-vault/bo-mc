'use strict'
const fs = require('fs')
const mineflayer = require('@wp2508/mineflayer')
const cfg = require('../config')
const { log } = require('./logger')
const { Brain, pathfinder } = require('./brain')

// ---------- Single-instance lock ----------
function acquireLock() {
  try {
    const old = parseInt(fs.readFileSync(cfg.lockFile, 'utf8'), 10)
    if (old && old !== process.pid) {
      try { process.kill(old, 0); log('LOGIN', `Another instance is already running (pid ${old}). Exiting.`); process.exit(1) } catch (e) { /* stale */ }
    }
  } catch (e) { /* no lock */ }
  fs.writeFileSync(cfg.lockFile, String(process.pid))
}
function releaseLock() {
  try { if (parseInt(fs.readFileSync(cfg.lockFile, 'utf8'), 10) === process.pid) fs.unlinkSync(cfg.lockFile) } catch (e) { /* */ }
}
acquireLock()

// ---------- Connection manager ----------
const stats = { deaths: 0 }
let bot = null
let brain = null
let attempts = 0
let reconnectTimer = null
let stableTimer = null
let lastReason = ''
let shuttingDown = false

const text = (r) => {
  if (!r) return ''
  if (typeof r === 'string') return r
  try { return JSON.stringify(r) } catch (e) { return String(r) }
}

function nextDelay() {
  const r = cfg.reconnect
  let d = Math.min(r.maxMs, r.baseMs * Math.pow(2, attempts))
  const reason = lastReason.toLowerCase()
  if (/throttl/.test(reason)) d = Math.max(d, r.throttleMinMs)
  if (/duplicate_login|logged in from another|already connected/.test(reason)) d = Math.max(d, r.duplicateMinMs)
  if (/invalid_player_movement/.test(reason)) d = Math.max(d, r.invalidMoveMinMs)
  return Math.round(d + Math.random() * 3000)
}

function scheduleReconnect() {
  if (shuttingDown || reconnectTimer) return
  if (/banned|ban/.test(lastReason.toLowerCase()) && /ban/.test(lastReason.toLowerCase())) {
    log('RECONNECT', `Looks like a ban (${lastReason.slice(0, 120)}). Not reconnecting. Fix it manually.`)
    return
  }
  const d = nextDelay()
  attempts++
  log('RECONNECT', `Waiting ${Math.round(d / 1000)} seconds (attempt ${attempts}, last reason: ${lastReason.slice(0, 100) || 'unknown'})`)
  reconnectTimer = setTimeout(() => { reconnectTimer = null; connect() }, d)
}

function connect() {
  if (bot) return // instance lama belum tertutup -> jangan buat baru
  log('LOGIN', `Connecting to ${cfg.server.host}:${cfg.server.port} as ${cfg.server.username} (v${cfg.server.version})`)
  let b
  try {
    b = mineflayer.createBot({
      host: cfg.server.host, port: cfg.server.port, username: cfg.server.username,
      version: cfg.server.version, auth: cfg.server.auth, checkTimeoutInterval: 60000
    })
  } catch (e) {
    lastReason = e.message
    log('LOGIN', `createBot failed: ${e.message}`)
    return scheduleReconnect()
  }
  bot = b
  b.loadPlugin(pathfinder)
  brain = new Brain(b, cfg, stats)

  b.once('login', () => log('LOGIN', 'Logged in'))
  b.once('spawn', () => {
    brain.start()
    clearTimeout(stableTimer)
    stableTimer = setTimeout(() => { attempts = 0 }, cfg.reconnect.stableAfterMs)
  })
  b.on('kicked', (r) => { lastReason = text(r); log('RECONNECT', `Kicked: ${lastReason.slice(0, 200)}`) })
  b.on('error', (e) => { lastReason = lastReason || e.message; log('SURVIVAL', `Error: ${e.message}`) })
  b.once('end', (r) => {
    clearTimeout(stableTimer)
    if (!lastReason) lastReason = text(r)
    log('RECONNECT', `Disconnected (${text(r)})`)
    if (brain) { brain.stop(); brain = null }
    b.removeAllListeners()
    bot = null // instance lama sudah benar-benar tertutup
    scheduleReconnect()
    lastReason = ''
  })
}

function shutdown(sig) {
  if (shuttingDown) return
  shuttingDown = true
  log('LOGIN', `${sig} received, shutting down`)
  clearTimeout(reconnectTimer)
  if (brain) brain.stop()
  try { if (bot) bot.quit() } catch (e) { /* */ }
  releaseLock()
  setTimeout(() => process.exit(0), 1500)
}
process.on('SIGINT', () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('exit', releaseLock)
process.on('uncaughtException', (e) => log('SURVIVAL', `uncaughtException: ${e.stack || e.message}`))
process.on('unhandledRejection', (e) => log('SURVIVAL', `unhandledRejection: ${e && e.message ? e.message : e}`))

connect()
