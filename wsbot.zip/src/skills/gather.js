'use strict'
const { goals } = require('mineflayer-pathfinder')
const {
  sleep, countSuffix, countItem, bestItem, goto, gotoNear, collectDrops,
  blacklist, isBlacklisted, posKey, inBlockedArea, blacklistArea
} = require('../util')

const STONE_NAMES = ['stone', 'cobblestone', 'andesite', 'diorite', 'granite']
const COAL_NAMES = ['coal_ore', 'deepslate_coal_ore']

function blockIds(ctx, pred) {
  return ctx.mcData.blocksArray.filter((b) => pred(b.name)).map((b) => b.id)
}

function toolFor(ctx, blockName) {
  if (blockName.endsWith('_log')) return bestItem(ctx, '_axe')
  if (STONE_NAMES.includes(blockName) || blockName.endsWith('_ore') || blockName === 'deepslate') return bestItem(ctx, '_pickaxe')
  return null
}

// Aman digali? Tidak ada lava/air di sisi, tidak ada blok jatuh di atasnya, bukan area terproteksi.
function safeToDig(ctx, block) {
  const { bot, mem } = ctx
  if (isBlacklisted(mem, posKey(block.position)) || inBlockedArea(mem, block.position)) return false
  const faces = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]
  for (const f of faces) {
    const n = bot.blockAt(block.position.offset(f[0], f[1], f[2]))
    if (n && (n.name === 'lava' || n.name === 'flowing_lava')) return false
  }
  const above = bot.blockAt(block.position.offset(0, 1, 0))
  if (above && (above.name === 'gravel' || above.name === 'sand' || above.name === 'lava')) return false
  // jangan menggali blok tepat di bawah kaki (hindari jatuh)
  const feet = bot.entity.position.floored()
  if (block.position.x === feet.x && block.position.z === feet.z && block.position.y < feet.y) return false
  return true
}

// Gali satu blok. Return true kalau blok benar-benar hilang.
async function digOne(ctx, block) {
  const { bot, mem, cfg, log } = ctx
  const name = block.name
  const tool = toolFor(ctx, name)
  if (tool) { try { await bot.equip(tool, 'hand') } catch (e) { /* */ } }
  if (!bot.canDigBlock(block)) { blacklist(mem, posKey(block.position), cfg.blacklistTtlMs); return false }
  mem.lastDig = { pos: block.position.clone(), at: Date.now() }
  try {
    await bot.dig(block, true)
  } catch (e) {
    blacklist(mem, posKey(block.position), cfg.blacklistTtlMs)
    return false
  }
  await sleep(200)
  const after = bot.blockAt(block.position)
  if (after && after.name === name) {
    // server mengembalikan blok -> kemungkinan proteksi (GriefPrevention dll.)
    log('SURVIVAL', `Dig rejected at ${block.position} (protected?), avoiding area`)
    blacklistArea(mem, block.position, 12, cfg.blacklistTtlMs * 3)
    return false
  }
  return true
}

// Cari & kumpulkan target. pred(name) menentukan blok target; done() menentukan selesai.
async function collect(ctx, label, pred, done, maxIter = 40) {
  const { bot, cfg, token, log, mem } = ctx
  const ids = blockIds(ctx, pred)
  let found = false
  for (let i = 0; i < maxIter && !token.cancelled && !done(); i++) {
    const block = bot.findBlock({
      matching: ids,
      maxDistance: cfg.gather.searchRadius,
      useExtraInfo: (b) => safeToDig(ctx, b)
    })
    if (!block) break
    found = true
    const ok = await gotoNear(ctx, block.position, 3, 20000)
    if (!ok) { blacklist(mem, posKey(block.position), cfg.blacklistTtlMs); continue }
    if (token.cancelled) break
    const cur = bot.blockAt(block.position)
    if (!cur || !pred(cur.name)) continue
    const dug = await digOne(ctx, cur)
    if (dug) await collectDrops(ctx, 6)
  }
  if (!found) log('SURVIVAL', `No ${label} found within ${cfg.gather.searchRadius} blocks`)
  return found
}

async function gatherWood(ctx, want) {
  ctx.log('SURVIVAL', 'Gathering wood')
  return collect(ctx, 'wood', (n) => n.endsWith('_log'),
    () => countSuffix(ctx.bot, '_log') >= want)
}

async function gatherStone(ctx, want) {
  ctx.log('SURVIVAL', 'Gathering stone')
  const cobble = () => countItem(ctx.bot, 'cobblestone')
  return collect(ctx, 'stone', (n) => n === 'stone' || n === 'cobblestone',
    () => cobble() >= want, 60)
}

async function gatherCoal(ctx, want) {
  ctx.log('SURVIVAL', 'Gathering coal')
  return collect(ctx, 'coal', (n) => COAL_NAMES.includes(n),
    () => countItem(ctx.bot, 'coal') >= want, 20)
}

// Jelajah: pilih titik acak 30-60 blok dari posisi sekarang
async function explore(ctx) {
  const { bot, log, mem } = ctx
  for (let i = 0; i < 4; i++) {
    const p = bot.entity.position
    const ang = Math.random() * Math.PI * 2
    const r = 30 + Math.random() * 30
    const x = Math.floor(p.x + Math.cos(ang) * r)
    const z = Math.floor(p.z + Math.sin(ang) * r)
    if (inBlockedArea(mem, { x, z })) continue
    log('SURVIVAL', `Exploring toward ${x}, ${z}`)
    const ok = await goto(ctx, new goals.GoalXZ(x, z), 25000)
    if (ok || ctx.token.cancelled) return true
  }
  return false
}

module.exports = { gatherWood, gatherStone, gatherCoal, explore }
