'use strict'
const { Vec3 } = require('vec3')
const { countItem, countSuffix, goto, gotoNear } = require('../util')
const { goals } = require('mineflayer-pathfinder')

// Craft hanya kalau bahan cukup: recipesFor() hanya mengembalikan recipe yang bisa dibuat dari inventory.
async function tryCraft(ctx, name, times = 1, table = null) {
  const { bot, mcData } = ctx
  const item = mcData.itemsByName[name]
  if (!item) return false
  const recipes = bot.recipesFor(item.id, null, 1, table)
  if (!recipes.length) return false
  try {
    await bot.craft(recipes[0], times, table)
    return true
  } catch (e) {
    ctx.log('CRAFT', `Craft ${name} failed: ${e.message}`)
    return false
  }
}

// Ubah log yang ada jadi planks sampai minimal n
async function ensurePlanks(ctx, n) {
  const { bot } = ctx
  while (countSuffix(bot, '_planks') < n) {
    const log = bot.inventory.items().find((i) => i.name.endsWith('_log'))
    if (!log) return false
    const planks = log.name.replace('_log', '_planks')
    if (!(await tryCraft(ctx, planks, 1))) return false
  }
  return true
}

async function ensureSticks(ctx, n) {
  const { bot } = ctx
  while (countItem(bot, 'stick') < n) {
    if (countSuffix(bot, '_planks') < 2 && !(await ensurePlanks(ctx, 2))) return false
    if (!(await tryCraft(ctx, 'stick', 1))) return false
  }
  return true
}

async function placeTable(ctx) {
  const { bot, mcData } = ctx
  const tableItem = bot.inventory.items().find((i) => i.name === 'crafting_table')
  if (!tableItem) return null
  await bot.equip(tableItem, 'hand')
  const feet = bot.entity.position.floored()
  const offs = [[1, 0], [-1, 0], [0, 1], [0, -1]]
  for (const [dx, dz] of offs) {
    const ref = bot.blockAt(feet.offset(dx, -1, dz))
    const spot = bot.blockAt(feet.offset(dx, 0, dz))
    const head = bot.blockAt(feet.offset(dx, 1, dz))
    if (ref && ref.boundingBox === 'block' && spot && spot.name === 'air' && head && head.name === 'air') {
      try {
        await bot.placeBlock(ref, new Vec3(0, 1, 0))
        return bot.blockAt(feet.offset(dx, 0, dz))
      } catch (e) { /* coba sisi lain */ }
    }
  }
  return null
}

async function ensureTable(ctx) {
  const { bot, mcData, log } = ctx
  const id = mcData.blocksByName.crafting_table.id
  let block = bot.findBlock({ matching: id, maxDistance: 32 })
  if (block) {
    if (bot.entity.position.distanceTo(block.position) > 4) await gotoNear(ctx, block.position, 3, 15000)
    return block
  }
  if (!bot.inventory.items().some((i) => i.name === 'crafting_table')) {
    if (!(await ensurePlanks(ctx, 4))) return null
    log('CRAFT', 'Creating crafting table')
    if (!(await tryCraft(ctx, 'crafting_table', 1))) return null
  }
  block = await placeTable(ctx)
  if (block) log('CRAFT', 'Crafting table placed')
  return block
}

// Craft tool/alat dengan dependensi (planks, stick, crafting table)
async function craftTool(ctx, name) {
  const { log } = ctx
  log('CRAFT', `Creating ${name}`)
  if (!(await ensureSticks(ctx, 2))) { log('CRAFT', `Not enough wood for sticks (${name})`); return false }
  const table = await ensureTable(ctx)
  if (!table) { log('CRAFT', 'No crafting table available'); return false }
  const ok = await tryCraft(ctx, name, 1, table)
  if (!ok) log('CRAFT', `Missing materials for ${name}`)
  return ok
}

module.exports = { tryCraft, ensurePlanks, ensureSticks, ensureTable, craftTool }
