'use strict'
const { countItem, tierOf, durabilityFraction, bestItem } = require('../util')
const craft = require('./craft')

const ARMOR = { helmet: 'head', chestplate: 'torso', leggings: 'legs', boots: 'feet' }
const ARMOR_TIER = { leather: 1, golden: 2, copper: 2.5, turtle: 2.5, chainmail: 3, iron: 4, diamond: 5, netherite: 6 }
const armorTier = (n) => ARMOR_TIER[n.split('_')[0]] || 0

async function equipArmor(ctx) {
  const { bot, mcData, cfg, log } = ctx
  for (const [piece, dest] of Object.entries(ARMOR)) {
    const cands = bot.inventory.items().filter((i) => i.name.endsWith('_' + piece) &&
      (durabilityFraction(i, mcData) ?? 1) > cfg.durability.minUsableFraction)
    if (!cands.length) continue
    cands.sort((a, b) => armorTier(b.name) - armorTier(a.name))
    const best = cands[0]
    const slot = bot.getEquipmentDestSlot(dest)
    const cur = bot.inventory.slots[slot]
    if (!cur || armorTier(best.name) > armorTier(cur.name)) {
      try { await bot.equip(best, dest); log('EQUIPMENT', `Equipped ${best.name}`) } catch (e) { /* */ }
    }
  }
}

// Kategori alat yang perlu diganti: durability terbaik < threshold, atau tidak ada sama sekali tidak dihitung.
function needsReplacement(ctx) {
  const { bot, mcData, cfg, mem } = ctx
  const out = []
  for (const cat of ['_pickaxe', '_axe', '_sword']) {
    const all = bot.inventory.items().filter((i) => i.name.endsWith(cat))
    if (!all.length) continue
    const best = bestItem(ctx, cat)
    const frac = best ? (durabilityFraction(best, mcData) ?? 1) : 0
    const healthy = all.some((i) => (durabilityFraction(i, mcData) ?? 1) >= cfg.durability.replaceBelowFraction)
    if (!healthy && frac < cfg.durability.replaceBelowFraction) {
      if ((mem.replaceCooldown[cat] || 0) < Date.now()) out.push(cat)
    }
  }
  return out
}

// Ganti = craft alat baru (kayu/batu). Repair via anvil/Mending belum diimplementasi (lihat README).
async function replace(ctx, cats) {
  const { bot, log, mem } = ctx
  for (const cat of cats) {
    log('EQUIPMENT', `${cat.slice(1)} durability low, trying to craft replacement`)
    const kind = cat.slice(1)
    const stone = countItem(bot, 'cobblestone') >= (kind === 'pickaxe' ? 3 : kind === 'axe' ? 3 : 2)
    const name = (stone ? 'stone' : 'wooden') + cat
    const ok = await craft.craftTool(ctx, name)
    if (!ok) {
      log('EQUIPMENT', `Cannot replace ${kind} now (materials missing); retry in 5 min`)
      mem.replaceCooldown[cat] = Date.now() + 300000
    }
  }
  return true
}

module.exports = { equipArmor, needsReplacement, replace }
