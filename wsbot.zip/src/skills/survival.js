'use strict'
const { goals } = require('mineflayer-pathfinder')
const { sleep, withTimeout, goto, gotoNear, collectDrops, blacklist, isBlacklisted } = require('../util')
const combat = require('./combat')

const NOT_FOOD = new Set(['rotten_flesh', 'spider_eye', 'poisonous_potato', 'pufferfish', 'suspicious_stew',
  'chorus_fruit', 'golden_apple', 'enchanted_golden_apple'])

function foodItems(ctx, allowRotten = false) {
  const { bot, mcData } = ctx
  return bot.inventory.items().filter((i) => mcData.foods[i.type] &&
    (!NOT_FOOD.has(i.name) || (allowRotten && i.name === 'rotten_flesh')))
}

async function eat(ctx) {
  const { bot, mcData, log } = ctx
  let items = foodItems(ctx)
  if (!items.length && bot.food <= 4) items = foodItems(ctx, true)
  if (!items.length) return false
  items.sort((a, b) => (mcData.foods[b.type].foodPoints || 0) - (mcData.foods[a.type].foodPoints || 0))
  const it = items[0]
  log('SURVIVAL', `Eating ${it.name} (food ${bot.food})`)
  try {
    await bot.equip(it, 'hand')
    await withTimeout(bot.consume(), 6000, () => bot.deactivateItem())
    return true
  } catch (e) {
    log('SURVIVAL', `Eat failed: ${e.message}`)
    return false
  }
}

// Berburu hewan pasif terdekat untuk makanan
async function hunt(ctx) {
  const { bot, mem, log, cfg } = ctx
  const animals = Object.values(bot.entities)
    .filter((e) => e !== bot.entity && e.name && combat.ANIMALS.has(e.name) &&
      !isBlacklisted(mem, 'e:' + e.id) && combat.dist(bot, e) <= 48)
    .sort((a, b) => combat.dist(bot, a) - combat.dist(bot, b))
  if (!animals.length) { log('SURVIVAL', 'No animals nearby'); return false }
  const target = animals[0]
  log('SURVIVAL', `Hunting ${target.name}`)
  const res = await combat.attackLoop(ctx, target, 25000)
  if (res === 'killed') {
    await collectDrops(ctx, 8)
    return true
  }
  // gagal membunuh (mungkin dilindungi claim/plugin) -> hindari entity ini
  blacklist(mem, 'e:' + target.id, cfg.blacklistTtlMs)
  return false
}

async function retreat(ctx) {
  const { bot, log } = ctx
  const mobs = combat.nearbyMobs(ctx, 28)
  if (!mobs.length) return rest(ctx)
  const p = mobs[0].position
  log('SURVIVAL', `Health ${Math.round(bot.health)}, retreating from ${mobs[0].name}`)
  await goto(ctx, new goals.GoalInvert(new goals.GoalNear(p.x, p.y, p.z, 30)), 12000)
  return true
}

async function rest(ctx) {
  const { bot, cfg } = ctx
  if (bot.food <= cfg.survival.eatBelowFood + 2 && foodItems(ctx).length) await eat(ctx)
  await sleep(2000)
  return true
}

// Ambil kembali item di titik kematian bila masih dekat & aman
async function recover(ctx) {
  const { mem, log, bot } = ctx
  const r = mem.recover
  if (!r || Date.now() > r.until) { mem.recover = null; return true }
  const d = bot.entity.position.distanceTo(r.pos)
  if (d > 200) { log('RESPAWN', 'Death point too far, skipping recovery'); mem.recover = null; return true }
  log('RESPAWN', `Trying to recover items near death point (${Math.round(d)} blocks)`)
  await gotoNear(ctx, r.pos, 2, 50000)
  await collectDrops(ctx, 12)
  mem.recover = null
  return true
}

module.exports = { foodItems, eat, hunt, retreat, rest, recover }
