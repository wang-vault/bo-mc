'use strict'
const { countItem, countSuffix, tierOf, bestItem } = require('../util')

const hasTier = (ctx, suffix, minTier) => {
  const it = bestItem(ctx, suffix)
  return !!it && tierOf(it.name) >= minTier
}

// Tujuan survival bertahap berdasarkan isi inventory (bukan urutan buta).
// Return { type: 'gather'|'craft', what, want } atau null kalau semua tujuan dasar tercapai.
function nextGoal(ctx) {
  const { bot, cfg } = ctx
  const logs = countSuffix(bot, '_log')
  const planks = countSuffix(bot, '_planks')
  const woodUnits = logs * 4 + planks
  const cobble = countItem(bot, 'cobblestone')
  const tableInInv = countItem(bot, 'crafting_table')

  if (!bestItem(ctx, '_pickaxe')) {
    // cukup untuk table(4 planks) + pickaxe(3 planks) + sticks(2 planks) = 9 planks
    if (woodUnits + tableInInv * 4 < 9) return { type: 'gather', what: 'wood', want: Math.max(4, logs + 2) }
    return { type: 'craft', what: 'wooden_pickaxe' }
  }
  if (cobble < 12) return { type: 'gather', what: 'stone', want: 12 }
  if (!hasTier(ctx, '_pickaxe', 3)) return { type: 'craft', what: 'stone_pickaxe' }
  if (!hasTier(ctx, '_sword', 3)) return { type: 'craft', what: 'stone_sword' }
  if (!hasTier(ctx, '_axe', 3)) return { type: 'craft', what: 'stone_axe' }
  if (logs < cfg.gather.logsWanted) return { type: 'gather', what: 'wood', want: cfg.gather.logsWanted }
  if (cobble < cfg.gather.cobbleWanted) return { type: 'gather', what: 'stone', want: cfg.gather.cobbleWanted }
  if (countItem(bot, 'coal') < 8) return { type: 'gather', what: 'coal', want: 8 }
  return null
}

module.exports = { nextGoal }
