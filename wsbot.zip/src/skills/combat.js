'use strict'
const { goals } = require('mineflayer-pathfinder')
const { sleep, bestItem, collectDrops, blacklist, isBlacklisted } = require('../util')

// Mob yang relatif aman dilawan dengan perlengkapan dasar
const SAFE = new Set(['zombie', 'husk', 'drowned', 'zombie_villager', 'spider', 'slime', 'skeleton'])
// Mob yang dihindari (bot mundur kalau dekat)
const DANGEROUS = new Set([
  'creeper', 'enderman', 'witch', 'pillager', 'vindicator', 'evoker', 'ravager', 'vex', 'phantom',
  'warden', 'blaze', 'ghast', 'wither_skeleton', 'piglin_brute', 'hoglin', 'zoglin', 'guardian',
  'elder_guardian', 'cave_spider', 'stray', 'bogged', 'breeze', 'silverfish', 'endermite'
])
const ANIMALS = new Set(['cow', 'pig', 'sheep', 'chicken', 'rabbit'])

const dist = (bot, e) => bot.entity.position.distanceTo(e.position)

function nearbyMobs(ctx, radius) {
  const { bot } = ctx
  return Object.values(bot.entities)
    .filter((e) => e !== bot.entity && e.position && e.name &&
      (SAFE.has(e.name) || DANGEROUS.has(e.name)) && dist(bot, e) <= radius)
    .sort((a, b) => dist(bot, a) - dist(bot, b))
}

function weapon(ctx) {
  return bestItem(ctx, '_sword') || bestItem(ctx, '_axe')
}

// Menilai ancaman: { danger: bool, reason, target }
function assess(ctx) {
  const { bot, cfg, mem } = ctx
  const mobs = nearbyMobs(ctx, cfg.combat.seekRadius)
  const hp = bot.health
  if (!mobs.length) return { danger: false, target: null, mobs }

  const close = mobs.filter((m) => dist(bot, m) <= 12)
  const dangerous = mobs.find((m) => DANGEROUS.has(m.name) && dist(bot, m) <= 8)
  if (dangerous) return { danger: true, reason: `mob berbahaya (${dangerous.name})`, mobs }
  if (close.length > cfg.combat.maxGroup) return { danger: true, reason: `kelompok musuh (${close.length})`, mobs }

  const candidates = mobs.filter((m) => SAFE.has(m.name) && !isBlacklisted(mem, 'e:' + m.id))
  const target = candidates[0] || null
  if (!target) return { danger: false, target: null, mobs }

  const d = dist(bot, target)
  const armed = !!weapon(ctx)
  // Cornered: musuh sudah menempel dan masih ada health -> lawan, lari dari zombie percuma
  if (hp < cfg.survival.fightMinHealth) {
    if (d <= 3 && hp > 5) return { danger: false, target, mobs, forced: true }
    return { danger: true, reason: 'health rendah', mobs }
  }
  if (target.name === 'skeleton' && hp < 16) return { danger: false, target: null, mobs }
  if (!armed && d > 5) return { danger: false, target: null, mobs } // tanpa senjata: hanya bela diri
  return { danger: false, target, mobs }
}

// Serang target sampai mati / timeout / health turun. Return 'killed' | 'retreat' | 'timeout' | 'cancelled' | 'lost'
async function attackLoop(ctx, target, maxMs) {
  const { bot, cfg, token, log } = ctx
  const w = weapon(ctx)
  if (w) { try { await bot.equip(w, 'hand') } catch (e) { /* abaikan */ } }
  const start = Date.now()
  let last = 0
  while (!token.cancelled) {
    if (Date.now() - start > maxMs) { bot.pathfinder.setGoal(null); return 'timeout' }
    if (!target.isValid || !bot.entities[target.id]) { bot.pathfinder.setGoal(null); return 'killed' }
    if (bot.health <= cfg.survival.retreatHealth) { bot.pathfinder.setGoal(null); return 'retreat' }
    const d = dist(bot, target)
    if (d > 40) { bot.pathfinder.setGoal(null); return 'lost' }
    if (d > cfg.combat.reach) {
      bot.pathfinder.setGoal(new goals.GoalFollow(target, 2), true)
    } else {
      bot.pathfinder.setGoal(null)
      try { await bot.lookAt(target.position.offset(0, (target.height || 1.5) * 0.9, 0), true) } catch (e) { /* */ }
      if (Date.now() - last >= cfg.combat.attackCooldownMs) {
        bot.attack(target)
        last = Date.now()
      }
    }
    await sleep(100)
  }
  bot.pathfinder.setGoal(null)
  return 'cancelled'
}

async function fight(ctx, target) {
  const { bot, log, mem } = ctx
  log('COMBAT', `Target ${target.name}`)
  const res = await attackLoop(ctx, target, ctx.cfg.combat.fightMaxMs)
  if (res === 'killed') {
    mem.kills++
    log('COMBAT', `${target.name} killed (total kills: ${mem.kills})`)
    await collectDrops(ctx, 8)
    return true
  }
  if (res === 'timeout' || res === 'lost') blacklist(mem, 'e:' + target.id, 120000)
  log('COMBAT', `Fight ended: ${res}`)
  return res !== 'retreat'
}

module.exports = { SAFE, DANGEROUS, ANIMALS, nearbyMobs, assess, attackLoop, fight, weapon, dist }
