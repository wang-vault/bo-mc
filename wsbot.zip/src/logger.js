'use strict'
// Log format: [TAG] pesan  (PM2 menambahkan timestamp sendiri dengan --time)
function log(tag, msg) {
  console.log(`[${tag}] ${msg}`)
}
// Log yang tidak mengulang pesan sama terlalu sering
const last = new Map()
function logOnce(tag, msg, everyMs = 60000) {
  const k = tag + msg
  const now = Date.now()
  if (now - (last.get(k) || 0) < everyMs) return
  last.set(k, now)
  log(tag, msg)
}
module.exports = { log, logOnce }
