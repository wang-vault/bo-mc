'use strict'
const fs = require('fs')
const { pathfinder, Movements } = require('mineflayer-pathfinder')
const { sleep, withTimeout, countItem, countSuffix, bestItem, durabilityFraction, blacklistArea } = require('./util')
const { log, logOnce } = require('./logger')
const survival = require('./skills/survival')
const gather = require('./skills/gather')
const craft = require('./skills/craft')
const combat = require('./skills/combat')
const equipment = require('./skills/equipment')
const { nextGoal } = require('./skills/progression')

// Satu Brain per koneksi bot. Semua listener didaftarkan sekali dan dilepas di stop().
class Brain {
  constructor(bot, cfg, sharedStats) {
    this.bot = bot
    this.cfg = cfg
    this.alive = false
    this.busy = false
    this.started = false
    this.state = 'INIT'
    this.token = { cancelled: false }
    this.resting = false
    this.loginAt = Date.now()
    this.timers = []
    this.listeners = []
    this.respawnTimer = null
    this.respawnTries = 0
    this.mem = {
      blacklist: new Map(), areas: [], replaceCooldown: {}, recover: null, lastDig: null,
      kills: 0, deaths: sharedStats.deaths, fails: {}, needExplore: false,
      skillObserved: 0, lastSkillMsg: null, target: null
    }
    this.sharedStats = sharedStats
    this.ctx = { bot, cfg, log, mem: this.mem, token: this.token, mcData: null }
  }

  on(evt, fn) { this.bot.on(evt, fn); this.listeners.push([evt, fn]) }

  start() {
    const bot = this.bot
    this.ctx.mcData = bot.registry // data yang sama dengan yang dipakai library (mendukung 26.3)
    const mv = new Movements(bot)
    mv.canDig = true
    mv.allow1by1towers = false
    mv.allowParkour = false
    mv.maxDropDown = 3
    mv.scafoldingBlocks = [] // jangan pakai blok inventory untuk scaffold (cobble dibutuhkan crafting)
    bot.pathfinder.setMovements(mv)

    this.on('death', () => this.onDeath())
    this.on('spawn', () => this.onSpawn())
    this.on('health', () => {
      if (this.state === 'FIGHT' && bot.health <= this.cfg.survival.retreatHealth) this.cancel('low health')
    })
    this.on('messagestr', (msg) => this.onChat(msg))

    this.timers.push(setInterval(() => this.tick(), this.cfg.tickMs))
    this.timers.push(setInterval(() => this.writeStatus(), this.cfg.statusEveryMs))
    this.timers.push(setInterval(() => this.periodicLog(), 600000))
    this.onSpawn() // event spawn pertama sudah terpancar sebelum listener ini terpasang
  }

  stop() {
    this.alive = false
    this.cancel('stop')
    this.timers.forEach(clearInterval)
    this.timers = []
    clearTimeout(this.respawnTimer)
    for (const [evt, fn] of this.listeners) this.bot.removeListener(evt, fn)
    this.listeners = []
    this.writeStatus('disconnected')
  }

  cancel(reason) {
    this.token.cancelled = true
    try { this.bot.pathfinder.stop() } catch (e) { /* */ }
    try { this.bot.clearControlStates() } catch (e) { /* */ }
    if (reason) logOnce('SURVIVAL', `Task cancelled: ${reason}`, 5000)
  }

  // ---------- Event handling ----------
  onSpawn() {
    const bot = this.bot
    if (!this.started) {
      this.started = true
      log('LOGIN', `Spawned at ${this.fmtPos()}`)
      this.alive = true
      return
    }
    if (this.state !== 'DEAD') return // spawn karena pindah dimensi/teleport, bukan respawn
    // spawn ulang setelah mati
    clearTimeout(this.respawnTimer)
    this.respawnTries = 0
    log('RESPAWN', `Respawned at ${this.fmtPos()}, settling...`)
    setTimeout(() => {
      this.alive = true
      this.state = 'CHECK_STATUS'
      const inv = bot.inventory.items().reduce((a, i) => a + i.count, 0)
      log('RESPAWN', `Status: health ${Math.round(bot.health)}, food ${bot.food}, inventory items ${inv}` +
        (inv === 0 ? ' (inventory empty - items dropped / no keepInventory)' : ''))
    }, this.cfg.respawn.settleMs)
  }

  onDeath() {
    if (!this.alive && this.state === 'DEAD') return // jangan proses dua kali
    const bot = this.bot
    this.alive = false
    this.state = 'DEAD'
    this.cancel()
    this.mem.deaths++
    this.sharedStats.deaths = this.mem.deaths
    const pos = bot.entity && bot.entity.position ? bot.entity.position.clone() : null
    if (pos) this.mem.recover = { pos, until: Date.now() + 300000 }
    this.mem.fails = {}
    this.resting = false
    log('DEATH', `Bot died (total deaths: ${this.mem.deaths})`)
    log('RESPAWN', 'Waiting for spawn')
    // mineflayer auto-respawn dulu; manual hanya fallback, terbatas
    this.respawnTimer = setTimeout(() => this.manualRespawn(), this.cfg.respawn.waitBeforeManualMs)
  }

  manualRespawn() {
    if (this.alive) return
    if (this.respawnTries >= this.cfg.respawn.maxRetries) {
      log('RESPAWN', `Respawn failed after ${this.respawnTries} retries; waiting for reconnect/PM2`)
      return
    }
    this.respawnTries++
    log('RESPAWN', `Manual respawn attempt ${this.respawnTries}/${this.cfg.respawn.maxRetries}`)
    try { this.bot.respawn() } catch (e) { log('RESPAWN', `respawn() error: ${e.message}`) }
    this.respawnTimer = setTimeout(() => this.manualRespawn(), this.cfg.respawn.retryEveryMs)
  }

  onChat(msg) {
    const m = this.mem
    // Indikasi proteksi claim setelah menggali -> hindari area itu
    if (m.lastDig && Date.now() - m.lastDig.at < 3000 &&
      /claim|permission|protected|izin|dilindungi|tidak bisa|can't|cannot/i.test(msg)) {
    blacklistArea(m, m.lastDig.pos, 16, this.cfg.blacklistTtlMs * 3)
      logOnce('SURVIVAL', `Protection message detected, avoiding area: ${msg.slice(0, 80)}`, 30000)
    }
    // AuraSkills: hanya dicatat kalau memang ada pesan XP yang terlihat (actionbar/chat)
    if (/(fighting|foraging|mining|excavation|farming).*\+\s?[\d.]+|\+\s?[\d.]+.*(xp|fighting|foraging|mining|excavation)/i.test(msg)) {
      m.skillObserved++
      m.lastSkillMsg = msg.slice(0, 100)
      logOnce('SKILL', `XP message observed: ${m.lastSkillMsg}`, 120000)
    }
  }

  periodicLog() {
    if (!this.alive) return
    if (this.mem.skillObserved === 0) log('SKILL', `AuraSkills XP status unverified (kills: ${this.mem.kills}, no XP message seen yet)`)
    else log('SKILL', `XP messages observed: ${this.mem.skillObserved}, last: ${this.mem.lastSkillMsg}`)
  }

  // ---------- Loop keputusan ----------
  async tick() {
    if (this.busy || !this.alive || !this.bot.entity) return
    this.busy = true
    try {
      const next = this.decide()
      await this.run(next)
    } catch (e) {
      log('SURVIVAL', `Tick error: ${e.message}`)
      await sleep(1500)
    } finally {
      this.busy = false
    }
  }

  decide() {
    const { bot, cfg, ctx, mem } = this
    ctx.mcData = ctx.mcData || bot.registry
    const sv = cfg.survival
    const threat = combat.assess(ctx)
    mem.target = threat.target ? threat.target.name : null

    if (bot.health <= sv.retreatHealth || threat.danger) {
      this.resting = true
      if (threat.danger) logOnce('SURVIVAL', `Danger: ${threat.reason || 'low health'}`, 10000)
      return 'RETREAT'
    }
    if (this.resting) {
      if (bot.health >= sv.resumeHealth) this.resting = false
      else return 'REST'
    }
    const foods = survival.foodItems(ctx).length
    if (bot.food <= sv.eatBelowFood && (foods || bot.food <= 4)) return 'EAT'
    if (threat.target && (threat.forced || bot.health >= sv.fightMinHealth)) return 'FIGHT'
    if (mem.recover) return 'RECOVER'
    if (bot.food <= sv.hungryFood || (foods < sv.minFoodItems && bot.food < 20 && this.can('FIND_FOOD'))) return 'FIND_FOOD'
    if (equipment.needsReplacement(ctx).length) return 'REPAIR_OR_REPLACE'
    if (mem.needExplore) return 'EXPLORE'
    const goal = nextGoal(ctx)
    if (goal && this.can(goal.type === 'craft' ? 'CRAFT_EQUIPMENT' : 'GATHER_RESOURCES')) {
      this.goal = goal
      return goal.type === 'craft' ? 'CRAFT_EQUIPMENT' : 'GATHER_RESOURCES'
    }
    this.goal = null
    return this.mem.target ? 'FIGHT' : 'EXPLORE'
  }

  // Task yang gagal berulang dijeda dulu supaya tidak berputar tanpa hasil
  can(state) {
    const f = this.mem.fails[state]
    return !f || f.n < 3 || Date.now() > f.until
  }
  fail(state) {
    const f = this.mem.fails[state] || { n: 0, until: 0 }
    f.n++
    if (f.n >= 3) f.until = Date.now() + 120000
    this.mem.fails[state] = f
  }
  succeed(state) { delete this.mem.fails[state] }

  async run(state) {
    const { cfg, ctx } = this
    this.state = state
    this.token = { cancelled: false }
    ctx.token = this.token
    const limit = cfg.timeouts[state] || 30000
    const timer = setTimeout(() => this.cancel(`${state} timeout`), limit)
    let ok = true
    try {
      ok = await withTimeout(this.exec(state), limit + 5000)
    } catch (e) {
      ok = false
      this.cancel()
      if (e.message !== 'timeout') log('SURVIVAL', `${state} error: ${e.message}`)
    } finally {
      clearTimeout(timer)
      try { this.bot.pathfinder.stop() } catch (e) { /* */ }
    }
    if (['GATHER_RESOURCES', 'CRAFT_EQUIPMENT', 'FIND_FOOD'].includes(state)) ok ? this.succeed(state) : this.fail(state)
    if (!ok && state === 'GATHER_RESOURCES') this.mem.needExplore = true
    if (state === 'EXPLORE') this.mem.needExplore = false
    await sleep(300)
  }

  async exec(state) {
    const { ctx, bot } = this
    switch (state) {
      case 'EAT': return survival.eat(ctx)
      case 'REST': return survival.rest(ctx)
      case 'RETREAT': return survival.retreat(ctx)
      case 'RECOVER': return survival.recover(ctx)
      case 'FIND_FOOD': return survival.hunt(ctx)
      case 'EXPLORE': return gather.explore(ctx)
      case 'REPAIR_OR_REPLACE': return equipment.replace(ctx, equipment.needsReplacement(ctx))
      case 'FIGHT': {
        const t = combat.assess(ctx).target
        if (!t) return true
        return combat.fight(ctx, t)
      }
      case 'CRAFT_EQUIPMENT': {
        await equipment.equipArmor(ctx)
        return craft.craftTool(ctx, this.goal.what)
      }
      case 'GATHER_RESOURCES': {
        await equipment.equipArmor(ctx)
        const g = this.goal
        if (g.what === 'wood') return gather.gatherWood(ctx, g.want)
        if (g.what === 'stone') return gather.gatherStone(ctx, g.want)
        return gather.gatherCoal(ctx, g.want)
      }
      default: return true
    }
  }

  // ---------- Status ----------
  fmtPos() {
    const p = this.bot.entity && this.bot.entity.position
    return p ? `${Math.round(p.x)}, ${Math.round(p.y)}, ${Math.round(p.z)}` : 'unknown'
  }

  snapshot(override) {
    const { bot, mem, ctx } = this
    const mcData = ctx.mcData
    const held = bot.heldItem ? bot.heldItem.name : null
    const armor = ['head', 'torso', 'legs', 'feet'].map((d) => {
      try { const it = bot.inventory.slots[bot.getEquipmentDestSlot(d)]; return it ? it.name : null } catch (e) { return null }
    })
    const dur = {}
    if (mcData) {
      for (const cat of ['_pickaxe', '_axe', '_sword']) {
        const it = bestItem(ctx, cat)
        if (it) { const f = durabilityFraction(it, mcData); dur[it.name] = f == null ? null : Math.round(f * 100) + '%' }
      }
    }
    return {
      updatedAt: Date.now(),
      connection: override || (this.alive ? 'alive' : 'dead/respawning'),
      state: this.state,
      health: Math.round(bot.health || 0),
      food: bot.food,
      position: this.fmtPos(),
      target: mem.target,
      goal: this.goal || null,
      held, armor, durability: dur,
      inventory: bot.inventory ? bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(', ') : '',
      kills: mem.kills,
      deaths: mem.deaths,
      uptimeSec: Math.round((Date.now() - this.loginAt) / 1000),
      auraSkills: mem.skillObserved ? `XP message observed x${mem.skillObserved}: ${mem.lastSkillMsg}` : 'unverified (no XP message seen)',
      pid: process.pid
    }
  }

  writeStatus(override) {
    try {
      const tmp = this.cfg.statusFile + '.tmp'
      fs.writeFileSync(tmp, JSON.stringify(this.snapshot(override), null, 2))
      fs.renameSync(tmp, this.cfg.statusFile)
    } catch (e) { /* status bukan fungsi kritis */ }
  }
}

module.exports = { Brain, pathfinder }
